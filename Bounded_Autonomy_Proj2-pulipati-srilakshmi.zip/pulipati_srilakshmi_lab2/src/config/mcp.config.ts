/**
 * MCP (Model Context Protocol) server setup
 *
 * Servers required by the review pipeline:
 * 1. GitHub – pull-request and repository operations
 * 2. ESLint – static analysis and style checking
 *
 * References:
 * - MCP overview: https://modelcontextprotocol.io
 * - GitHub MCP server: https://github.com/github/github-mcp-server
 * - ESLint MCP: https://eslint.org/docs/latest/use/mcp
 */

export const mcpServersConfig = {
  /**
   * GitHub MCP server configuration.
   * Maps GITHUB_TOKEN from the environment to the token name
   * expected by the official GitHub MCP package.
   */
  github: {
    type: 'stdio' as const,
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-github'],
    env: {
      GITHUB_PERSONAL_ACCESS_TOKEN: process.env.GITHUB_TOKEN || '',
    },
  },

  /**
   * ESLint MCP server configuration.
   * Provides linting capabilities for code-quality analysis.
   */
  eslint: {
    type: 'stdio' as const,
    command: 'npx',
    args: ['-y', '@eslint/mcp@latest'],
    env: {},
  },
};
