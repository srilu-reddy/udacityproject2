import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts/code-quality-analyzer.prompt.js';

/**
 * Specialist agent responsible for evaluating code quality aspects
 * including security, performance, style, and maintainability.
 */
export const codeQualityAnalyzer: AgentDefinition = {
  description:
    'Inspects source changes for security issues, performance problems, maintainability gaps, style drift, possible bugs, and departures from best practices.',
  model: 'inherit',
  tools: ['mcp__github__pull_request_read', 'Skill'],
  prompt: CODE_QUALITY_ANALYZER_PROMPT,
};
