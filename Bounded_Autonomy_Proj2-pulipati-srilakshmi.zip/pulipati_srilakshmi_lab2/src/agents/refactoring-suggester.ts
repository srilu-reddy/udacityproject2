import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { REFACTORING_SUGGESTER_PROMPT } from '../prompts/refactoring-suggester.prompt.js';

/**
 * Specialist agent that proposes concrete refactoring steps
 * to improve readability, structure, and modern practices.
 */
export const refactoringSuggester: AgentDefinition = {
  description:
    'Examines pull-request diffs and offers concrete refactoring steps that improve readability, maintainability, modernization, and design quality.',
  model: 'inherit',
  tools: ['mcp__github__pull_request_read', 'Skill'],
  prompt: REFACTORING_SUGGESTER_PROMPT,
};
