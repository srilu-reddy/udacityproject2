import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { TEST_COVERAGE_ANALYZER_PROMPT } from '../prompts/test-coverage-analyzer.prompt.js';

/**
 * Specialist agent that inspects test presence and coverage
 * for the files modified in a pull request.
 */
export const testCoverageAnalyzer: AgentDefinition = {
  description:
    'Reviews pull-request diffs to evaluate test coverage, identify missing tests, untested paths, branches, edge cases, and overall test quality.',
  model: 'inherit',
  tools: ['mcp__github__pull_request_read', 'Skill'],
  prompt: TEST_COVERAGE_ANALYZER_PROMPT,
};
