# Bounded Autonomy — Multi-Agent Code Review Lab

Multi-agent GitHub pull-request reviewer that coordinates specialist agents focused on code quality, test coverage, and refactoring suggestions. Implemented with the Claude Agent SDK and MCP (Model Context Protocol).

**Author:** PULIPATI SRILAKSHMI  
**Date:** 2026-09-30

## Overview

The system launches three specialist agents in parallel, collects their structured outputs, and produces a unified review report in Markdown, HTML, and JSON.

| Agent | Responsibility |
|-------|----------------|
| **Code Quality Analyzer** | Security, performance, maintainability, style, bug risk |
| **Test Coverage Analyzer** | Missing tests, untested paths, edge cases |
| **Refactoring Suggester** | Concrete improvement suggestions for readability and design |

An orchestrator merges the results, applies rate limiting, and writes reports under `reports/`.

## Project Layout

```
src/
  agents/          Specialist agent definitions
  config/          MCP and environment configuration
  prompts/         Prompt templates for each agent
  types/           Zod schemas and TypeScript types
  utils/           Logging, rate limiting, report generation, error handling
  main.ts          CLI entry point
  orchestrator.ts  Coordination logic
tests/             Unit tests (Vitest)
reports/           Generated review artifacts
.claude/skills/    Optional Claude Skills for domain guidance
```

## Prerequisites

- Node.js 18+
- Anthropic API key **or** AWS Bedrock credentials
- (Optional) GitHub token for higher API rate limits

## Setup

**Vocareum Workspace:**

```bash
cd /voc/work/cd14715-claude-code-classroom
npm install
cd project/starter
cp .env.example .env
```

**Local:**

```bash
git clone https://github.com/udacity/cd14715-claude-code-classroom.git
cd cd14715-claude-code-classroom/project/starter
npm install
cp .env.example .env
```

## Configuration

Edit `.env`:

**Vocareum (API keys already present):**
```bash
ANTHROPIC_MODEL=claude-sonnet-4-5-20250929
PROJECT_ROOT=/voc/work/cd14715-claude-code-classroom/project/starter
# GITHUB_TOKEN=ghp_your-token-here   # optional
LOG_LEVEL=info
```

**Local with your own key:**
```bash
ANTHROPIC_API_KEY=sk-ant-your-key-here
ANTHROPIC_MODEL=claude-sonnet-4-5-20250929
PROJECT_ROOT=/absolute/path/to/project/starter
# GITHUB_TOKEN=ghp_your-token-here
LOG_LEVEL=info
```

## Running the Reviewer

```bash
# Development
npm run dev -- <owner> <repo> <pr-number>

# Production
npm run build
npm start <owner> <repo> <pr-number>

# Example
npm run dev -- facebook react 12345
```

## Testing

```bash
npm test
npm test -- orchestrator.test.ts
npm test -- --watch
```

## Key Technologies

- Claude Agent SDK — multi-agent orchestration
- Model Context Protocol (MCP) — external data access
- Zod — schema validation
- TypeScript — static typing
- Vitest — test runner
- Winston — structured logging

## Completion Checklist

- [ ] `npm run build` succeeds with no TypeScript errors
- [ ] `npm test` passes
- [ ] Real PR review works: `npm start owner repo pr-number`
- [ ] Reports generated in MD / HTML / JSON
- [ ] Rate limiting active (optional)
- [ ] Errors handled gracefully (recommended)

## Resources

- [Claude Agent SDK](https://github.com/anthropics/claude-agent-sdk)
- [Model Context Protocol](https://modelcontextprotocol.io/)
- [Anthropic API Docs](https://docs.anthropic.com/)
- [Zod Documentation](https://zod.dev/)

Happy reviewing!
