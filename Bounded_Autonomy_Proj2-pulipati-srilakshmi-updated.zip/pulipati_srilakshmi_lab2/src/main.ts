import * as dotenv from 'dotenv';
import { mkdir, writeFile } from 'node:fs/promises';

import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator } from './utils/report-generator.js';

dotenv.config();

/**
 * Command-line entry point for the bounded-autonomy multi-agent review pipeline.
 * Usage: npm run dev -- <owner> <repo> <pr-number>
 */
async function main(): Promise<void> {
  const [repoOwner, repoName, prArg] = process.argv.slice(2);

  if (!repoOwner || !repoName || !prArg) {
    console.error('Usage: npm run dev -- <owner> <repo> <pr-number>');
    process.exit(1);
  }

  const prNumber = Number(prArg);

  if (!Number.isInteger(prNumber) || prNumber <= 0) {
    console.error('Error: PR number must be a positive integer.');
    process.exit(1);
  }

  const hasAnthropicKey = Boolean(process.env.ANTHROPIC_API_KEY);
  const hasAwsCredentials =
    Boolean(process.env.AWS_ACCESS_KEY_ID) &&
    Boolean(process.env.AWS_SECRET_ACCESS_KEY);

  if (!hasAnthropicKey && !hasAwsCredentials) {
    console.error(
      'Authentication required. Provide either:\n' +
        '  1. ANTHROPIC_API_KEY for the Anthropic API, or\n' +
        '  2. AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY for AWS Bedrock.'
    );
    process.exit(1);
  }

  if (hasAnthropicKey) {
    console.log('Using Anthropic API credentials');
  } else {
    if (!process.env.AWS_REGION) {
      console.error(
        'Error: AWS_REGION must be set when authenticating via AWS Bedrock.'
      );
      process.exit(1);
    }
    console.log('Using AWS Bedrock credentials');
  }

  const modelName = process.env.ANTHROPIC_MODEL;

  if (!modelName) {
    console.error(
      'Error: ANTHROPIC_MODEL environment variable is required.'
    );
    process.exit(1);
  }

  console.log(`Starting review of ${repoOwner}/${repoName} PR #${prNumber}...`);

  try {
    const orchestrator = new CodeReviewOrchestrator({
      model: modelName,
    });

    const reviewResult = await orchestrator.reviewPullRequest(
      repoOwner,
      repoName,
      prNumber
    );

    const generator = new ReportGenerator();

    const mdContent = generator.generateMarkdownReport(reviewResult);
    const htmlContent = generator.generateHTMLReport(reviewResult);
    const jsonContent = generator.generateJSONReport(reviewResult);

    await mkdir('reports', { recursive: true });

    const outputPrefix = `${repoOwner}_${repoName}_${prNumber}`;

    await Promise.all([
      writeFile(`reports/${outputPrefix}.md`, mdContent, 'utf-8'),
      writeFile(`reports/${outputPrefix}.html`, htmlContent, 'utf-8'),
      writeFile(`reports/${outputPrefix}.json`, jsonContent, 'utf-8'),
    ]);

    console.log('Code review finished successfully.');
    console.log(`  Markdown : reports/${outputPrefix}.md`);
    console.log(`  HTML     : reports/${outputPrefix}.html`);
    console.log(`  JSON     : reports/${outputPrefix}.json`);
  } catch (err) {
    console.error(
      'Code review failed:',
      err instanceof Error ? err.message : String(err)
    );
    process.exitCode = 1;
  }
}

main().catch((err: unknown) => {
  console.error(
    'Unexpected failure:',
    err instanceof Error ? err.message : String(err)
  );
  process.exitCode = 1;
});
