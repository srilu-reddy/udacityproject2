
/**
 * Lightweight rate limiter protecting against Anthropic API throttling.
 *
 * Implementation notes:
 * - Sliding-window tracking of recent requests and token consumption
 * - Caps concurrent in-flight requests
 * - Estimates token usage so the per-minute budget is respected
 */

export interface RateLimiterConfig {
  /** Maximum requests per minute */
  maxRequestsPerMinute: number;
  /** Maximum tokens per minute */
  maxTokensPerMinute: number;
  /** Maximum concurrent requests */
  maxConcurrent: number;
}

export const DEFAULT_RATE_LIMITS: RateLimiterConfig = {
  maxRequestsPerMinute: 50,
  maxTokensPerMinute: 100000,
  maxConcurrent: 5
};

interface RequestRecord {
  timestamp: number;
  tokens: number;
}

export class RateLimiter {
  private config: RateLimiterConfig;
  private requestLog: RequestRecord[] = [];
  private inFlightCount: number = 0;
  private pendingResolvers: Array<() => void> = [];

  constructor(config: Partial<RateLimiterConfig> = {}) {
    this.config = { ...DEFAULT_RATE_LIMITS, ...config };
  }

  async acquire(estimatedTokens: number = 1000): Promise<void> {
    while (true) {
      if (this.inFlightCount >= this.config.maxConcurrent) {
        await this.waitForSlot();
      }

      if (this.canProceed(estimatedTokens)) {
        this.inFlightCount++;

        this.requestLog.push({
          timestamp: Date.now(),
          tokens: estimatedTokens
        });

        return;
      }

      await this.waitForRateLimit(estimatedTokens);
    }
  }

  release(actualTokens?: number): void {
    this.inFlightCount = Math.max(0, this.inFlightCount - 1);

    if (actualTokens !== undefined && this.requestLog.length > 0) {
      const lastIndex = this.requestLog.length - 1;
      const lastRequest = this.requestLog[lastIndex];

      if (lastRequest !== undefined) {
        lastRequest.tokens = actualTokens;
      }
    }

    const next = this.pendingResolvers.shift();
    if (next) {
      next();
    }
  }

  getStatus(): {
    activeRequests: number;
    requestsInWindow: number;
    tokensInWindow: number;
    availableRequests: number;
    availableTokens: number;
  } {
    this.pruneOldRecords();

    const requestsInWindow = this.requestLog.length;
    const tokensInWindow = this.requestLog.reduce(
      (sum, request) => sum + request.tokens,
      0
    );

    return {
      activeRequests: this.inFlightCount,
      requestsInWindow,
      tokensInWindow,
      availableRequests: Math.max(
        0,
        this.config.maxRequestsPerMinute - requestsInWindow
      ),
      availableTokens: Math.max(
        0,
        this.config.maxTokensPerMinute - tokensInWindow
      )
    };
  }

  canProceed(estimatedTokens: number = 1000): boolean {
    this.pruneOldRecords();

    if (this.inFlightCount >= this.config.maxConcurrent) {
      return false;
    }

    const requestsInWindow = this.requestLog.length;

    const tokensInWindow = this.requestLog.reduce(
      (sum, request) => sum + request.tokens,
      0
    );

    return (
      requestsInWindow < this.config.maxRequestsPerMinute &&
      tokensInWindow + estimatedTokens <= this.config.maxTokensPerMinute
    );
  }

  private async waitForSlot(): Promise<void> {
    await new Promise<void>((resolve) => {
      this.pendingResolvers.push(resolve);
    });
  }

  private async waitForRateLimit(
    estimatedTokens: number
  ): Promise<void> {
    while (!this.canProceed(estimatedTokens)) {
      this.pruneOldRecords();

      if (this.requestLog.length === 0) {
        break;
      }

      const oldestRequest = this.requestLog[0];

      if (!oldestRequest) {
        break;
      }

      const expirationTime = oldestRequest.timestamp + 60000;
      const waitTime = Math.min(
        5000,
        Math.max(100, expirationTime - Date.now() + 100)
      );

      await new Promise<void>((resolve) => {
        setTimeout(resolve, waitTime);
      });
    }
  }

  private pruneOldRecords(): void {
    const cutoff = Date.now() - 60000;

    this.requestLog = this.requestLog.filter(
      (request) => request.timestamp > cutoff
    );
  }
}

export function withRateLimit<T>(
  rateLimiter: RateLimiter,
  fn: () => Promise<T>,
  estimatedTokens: number = 1000
): Promise<T> {
  return new Promise(async (resolve, reject) => {
    try {
      await rateLimiter.acquire(estimatedTokens);
      const result = await fn();
      rateLimiter.release();
      resolve(result);
    } catch (error) {
      rateLimiter.release();
      reject(error);
    }
  });
}

export const globalRateLimiter = new RateLimiter();
