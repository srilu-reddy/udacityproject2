import winston from 'winston';

/**
 * Application logger built on Winston.
 * Writes structured JSON to console and rotating log files.
 */
export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'pulipati-multiagent-review' },
  transports: [
    // Error logs
    new winston.transports.File({
      filename: 'logs/error.log',
      level: 'error'
    }),
    // Combined logs
    new winston.transports.File({
      filename: 'logs/combined.log'
    })
  ]
});

// Console output for non-production
if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.combine(
      winston.format.colorize(),
      winston.format.printf(({ level, message, timestamp, ...meta }) => {
        const metaStr = Object.keys(meta).length > 1
          ? `\n${JSON.stringify(meta, null, 2)}`
          : '';
        return `${timestamp} [${level}]: ${message}${metaStr}`;
      })
    )
  }));
}

/**
 * Convenience helpers for the most frequent log events
 */
export const logReviewStart = (owner: string, repo: string, prNumber: number) => {
  logger.info('Review pipeline started', { owner, repo, prNumber });
};

export const logReviewComplete = (
  owner: string,
  repo: string,
  prNumber: number,
  score: number,
  duration: number
) => {
  logger.info('Review pipeline finished', {
    owner,
    repo,
    prNumber,
    score,
    duration,
    status: 'success'
  });
};

export const logReviewError = (
  owner: string,
  repo: string,
  prNumber: number,
  error: Error
) => {
  logger.error('Review pipeline failed', {
    owner,
    repo,
    prNumber,
    error: error.message,
    stack: error.stack,
    status: 'failed'
  });
};

export const logAgentStart = (agentName: string, file: string) => {
  logger.debug('Specialist agent starting', { agent: agentName, file });
};

export const logAgentComplete = (agentName: string, file: string, duration: number) => {
  logger.debug('Specialist agent finished', { agent: agentName, file, duration });
};

