import { query } from '@anthropic-ai/claude-agent-sdk';
import { zodToJsonSchema } from 'zod-to-json-schema';

import type { ReviewReport } from './types/report-types.js';
import { ReviewReportSchema } from './types/report-types.js';
import { mcpServersConfig } from './config/mcp.config.js';
import {
  codeQualityAnalyzer,
  testCoverageAnalyzer,
  refactoringSuggester,
} from './agents/index.js';
import { buildOrchestratorPrompt } from './prompts/orchestrator.prompt.js';

export interface OrchestratorOptions {
  model?: string;
  cwd?: string;
  timeoutMs?: number;
}

/**
 * Drives the multi-agent code-review workflow for one pull request.
 */
export class CodeReviewOrchestrator {
  private readonly opts: OrchestratorOptions;

  constructor(opts: OrchestratorOptions = {}) {
    this.opts = opts;
  }

  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    const startTime = Date.now();

    if (!owner || !repo || !Number.isInteger(prNumber) || prNumber <= 0) {
      throw new Error('Invalid pull request parameters supplied.');
    }

    const orchestratorPrompt = buildOrchestratorPrompt(owner, repo, prNumber);

    const agentStream = query({
      prompt: orchestratorPrompt,
      options: {
        model:
          this.opts.model ||
          process.env.ANTHROPIC_MODEL ||
          'claude-sonnet-4-5-20250929',

        cwd: this.opts.cwd || process.cwd(),

        mcpServers: mcpServersConfig,

        agents: {
          codeQualityAnalyzer,
          testCoverageAnalyzer,
          refactoringSuggester,
        },

        allowedTools: [
          'Task',
          'mcp__github__pull_request_read',
          'mcp__github__get_file_contents',
          'Skill',
        ],

        outputFormat: {
          type: 'json_schema',
          schema: zodToJsonSchema(ReviewReportSchema as any, {
            $refStrategy: 'root',
          }),
        },
      },
    });

    let reportData: ReviewReport | undefined;

    for await (const msg of agentStream) {
      if (
        msg.type === 'result' &&
        msg.subtype === 'success' &&
        msg.structured_output
      ) {
        reportData = ReviewReportSchema.parse(msg.structured_output);
      }

      if (msg.type === 'result' && msg.subtype !== 'success') {
        throw new Error(`Code review failed with subtype: ${msg.subtype}`);
      }
    }

    if (!reportData) {
      throw new Error(
        'Review finished without producing a valid structured report.'
      );
    }

    const finalReport: ReviewReport = {
      ...reportData,
      metadata: {
        ...reportData.metadata,
        analyzedAt: new Date().toISOString(),
        duration: Date.now() - startTime,
      },
    };

    return ReviewReportSchema.parse(finalReport);
  }
}
